import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class loginpage implements ActionListener {
    
    HashMap<String,String> loginInfo = new HashMap<String,String>();
    JFrame frame = new JFrame();
    JButton employeeLoginButton = new JButton("Login employee");
    JButton ownerLoginButton = new JButton("login owner");
    JButton resetButton = new JButton("Reset");
    JTextField usernameField = new JTextField();
    JPasswordField userPasswordField = new JPasswordField();
    JTextField pqTextField = new JTextField();
    JLabel usernameLabel = new JLabel("Username :");
    JLabel userpasswordLabel = new JLabel("Password");
    JLabel msg = new JLabel();
    JComboBox comboBox;
     
    ArrayList<String> owner = new ArrayList<String>();
    ArrayList<String> employee = new ArrayList<String>();
    ArrayList<String> employeePq = new ArrayList<String>();
    ArrayList<String> ownerPq = new ArrayList<String>();

    private int x = 0;

    loginpage()
    {
        String [] pq = {"Dream Car", "Favorite food", "Favorite footballer"};

        ImageIcon icon = new ImageIcon ("lock.png"); //sets the application icon

        // the try catch is used to access the respective security files to get the data to be used in the login system
        try 
        {
            
            File ownerFile = new File("ownerSecurityInfo.txt");
            Scanner reader = new Scanner(ownerFile);

            File employeeFile = new File("EmployeeSecurityInfo.txt");
            Scanner employeeReader = new Scanner(employeeFile);

            File employeePqFile = new File("employeePqAnswer.txt");
            Scanner employeePqReader = new Scanner(employeePqFile);

            File ownerPqFile = new File("ownerPqAnswer.txt");
            Scanner ownerPqReader = new Scanner(ownerPqFile);

            while (reader.hasNextLine()) 
            {
                String data = reader.nextLine();
                owner.add(data);
            }
            reader.close();
            System.out.println(owner);

            while (employeeReader.hasNextLine()) 
            {
                String data = employeeReader.nextLine();
                employee.add(data);
            }
            employeeReader.close();
            System.out.println(employee);

            while (employeePqReader.hasNextLine()) 
            {
                String data = employeePqReader.nextLine();
                employeePq.add(data);
            }
            System.out.println(employeePq);
            employeePqReader.close();

            while (ownerPqReader.hasNextLine()) 
            {
                String data = ownerPqReader.nextLine();
                ownerPq.add(data);
            }
            System.out.println(ownerPq);
            ownerPqReader.close();
        } 
        catch (FileNotFoundException e) 
        {
           System.out.println("an error has occured rebooting in process");
        }
        
        usernameLabel.setBounds(50, 100, 75, 25);
        userpasswordLabel.setBounds(50, 150, 75, 25);
        
        msg.setBounds(125, 250, 250, 35);

        usernameField.setBounds(125,100,200,25);
        userPasswordField.setBounds(125,150,200,25);
       
        employeeLoginButton.setBounds(175,250,100,100);
        employeeLoginButton.addActionListener(this);
        employeeLoginButton.setFocusable(false);
        ownerLoginButton.setBounds(175, 300, 100, 100);
        ownerLoginButton.addActionListener(this);
        ownerLoginButton.setFocusable(false);
        resetButton.setBounds(200,300,100,100);
        resetButton.addActionListener(this);
        resetButton.setFocusable(false);
        
        pqTextField.setBounds(2, 250, 100, 25);
        comboBox = new JComboBox<>(pq);
        comboBox.setBounds(2, 300, 100, 100);
        comboBox.addActionListener(this);

        frame.add(msg);
        frame.add(usernameLabel);
        frame.add(usernameField);
        frame.add(userpasswordLabel);
        frame.add(userPasswordField);
        frame.add(employeeLoginButton);
        frame.add(ownerLoginButton);
        frame.add(resetButton);
        frame.add(comboBox);
        frame.add(pqTextField);
        frame.setIconImage(icon.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String username = usernameField.getText();
        String password = String.valueOf(userPasswordField.getPassword());
        String pqString = pqTextField.getText();
        String ownerUsername = usernameField.getText();
        String ownerPassword = String.valueOf(userPasswordField.getPassword());
        String ownerpqString = pqTextField.getText();
        
        ActionEvent customEvent = new ActionEvent(comboBox, ActionEvent.ACTION_PERFORMED, "command");
        // line 145 is used to create another action event to faciliate the personal question section

        if(e.getSource() == resetButton)
        {
            usernameField.setText("");
            userPasswordField.setText("");
            pqTextField.setText("");
        }

        if(e.getSource() == employeeLoginButton)
        {
            if (username.equals(employee.get(0)))
            {
                if(password.equals(employee.get(1)))
                {
                   if (customEvent.getSource() == comboBox) 
                   {
                        if(comboBox.getSelectedIndex() == 0)
                            {
                                if (pqString.equals(employeePq.get(0))) 
                                {
                                    System.out.println("YOOOOOO");
                                    new employeeMainMenu();
                                    frame.dispose();

                                } 
                                else
                                {
                                    System.out.println("red Among us");
                                } 

                            }
                        if (comboBox.getSelectedIndex() == 1) 
                        {
                            if (pqString.equals(employeePq.get(1))) 
                            {
                                System.out.println("YOOOOOO again");
                                new employeeMainMenu();
                                frame.dispose();
                                
                            } 
                            else 
                            {
                                System.out.println("Blue Among us");
                            }
                        }
                        if (comboBox.getSelectedIndex() == 2) 
                        {
                            if(pqString.equals(employeePq.get(2)))
                            {
                                System.out.println("YOOOO once more");
                               new employeeMainMenu();
                                frame.dispose();
                            }
                            else
                            {
                                System.out.println("Green Among us");
                            }
                        }
                   }
                }   
            }
            else
            {
                msg.setForeground(Color.red);
                msg.setText("incorrect credentials");
            }
        }
        if (e.getSource() == ownerLoginButton)
        {
            
            if (ownerUsername.equals(owner.get(0))) 
            {
                if (ownerPassword.equals(owner.get(1))) 
                {
                    if (customEvent.getSource() == comboBox) 
                    {
                       if(comboBox.getSelectedIndex() == 0)
                       {
                            if (ownerpqString.equals(ownerPq.get(0))) 
                            {
                                System.out.println("Owner");
                                new Ownermainmenu();
                                frame.dispose();
                            }
                            else
                            {
                                System.out.println("white among us");
                            }  
                       }
                       if (comboBox.getSelectedIndex() == 1) 
                       {
                            if (ownerpqString.equals(ownerPq.get(1))) 
                            {
                                System.out.println("Owner too");
                                new Ownermainmenu();
                                frame.dispose();
                            } 
                            else 
                            {
                                System.out.println("brown among us");
                            }
                       }
                       if (comboBox.getSelectedIndex() == 2) 
                       {
                            if (ownerpqString.equals(ownerPq.get(2))) 
                            {
                                System.out.println("owner again");
                                new Ownermainmenu();
                                frame.dispose();                                
                            } 
                            else 
                            {
                                System.out.println("orange among us");
                            }
                       } 
                    }    
                }
            }
            else
            {
                msg.setForeground(Color.red);
                msg.setText("incorrect credentials");
            }
            
        }        
    }
    
     public void disposeFrame() 
     {
        frame.dispose();
    }
}
