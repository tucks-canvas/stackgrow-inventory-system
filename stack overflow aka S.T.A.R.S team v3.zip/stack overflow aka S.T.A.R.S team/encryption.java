// import java.io.File;
// import java.io.FileWriter;
// import java.util.*;

// public class encryption {
//     private Scanner scanner;
//     private Random Random;
//     private ArrayList<Character> list;
//     private ArrayList<Character> shuffledList;
//     private char Character;
//     private char[] letters;
//     private String line;

//     encryption()
//     {
//         scanner = new Scanner(System.in);
//         Random = new Random();
//         list = new ArrayList();
//         shuffledList = new ArrayList();
//         Character = ' ';
        
//     }

//     public void encrypt()
//     {
        
//     }

//     public void decrpyt()
//     {
        
//     }
    
//     public ArrayList getOwner()
//     {
//         return null;
//     }
    
//     public ArrayList getEmployee()
//     {
//         return null;
//     }
// }
