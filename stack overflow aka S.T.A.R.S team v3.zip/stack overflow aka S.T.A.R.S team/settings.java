// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;
// import javax.swing.ImageIcon;
// import javax.swing.JButton;
// import javax.swing.JFrame;
// import javax.swing.JLabel; 
// import javax.swing.JTextField;

// public class settings implements ActionListener{

    

//     JFrame frame = new JFrame();
//     JLabel label = new JLabel();

//     JButton securityInfo = new JButton("Security details");   
//     JTextField tester = new JTextField();
//     settings(int x)
//     {
//         ImageIcon settingsIcon = new ImageIcon("settingsIcon.png");
//         System.out.println(x);
//         securityInfo.setBounds(125,200,100,25);
//         securityInfo.addActionListener(this);
//         securityInfo.setFocusable(false);
        
//         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         frame.setIconImage(settingsIcon.getImage());
//         frame.add(securityInfo);
//         frame.setSize(420, 420);
//         frame.setLayout(null);
//         frame.setVisible(true);
//     }

//     @Override
//     public void actionPerformed(ActionEvent e)
//     {

//         // if(e.getSource() == securityInfo)
//         // {
//         //     frame.dispose();
//         //     new employeeSecurityDetails();
            
//         // }
//     }

//     public void disposeFrame() {
//         frame.dispose();
//     }
    
// }
