import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ownerSecurityDetails extends JFrame implements ActionListener
{

    JButton passwordButton = new JButton("change password");
    JButton usernameButton = new JButton("Change username");
    JButton CarPqButton = new JButton("Change favorite car answer");
    JButton FoodPqButton = new JButton("Change favorite food answer");
    JButton FootballerPqButton = new JButton("Change favorite footballer answer");
    
    JTextField newUsernamTextField = new JTextField();
    JLabel currentUsernameLabel = new JLabel("Current username :");
    JLabel newUsernamLabel = new JLabel("enter new username :");

    JTextField newPasswordtTextField = new JTextField();
    JLabel currentPasswordLabel = new JLabel("Current password :");
    JLabel newPasswordLabel = new JLabel("Enter new password :");

    JTextField newDreamCarTextField = new JTextField();
    JTextField newFavoriteFoodTextField = new JTextField();
    JTextField newFavoriteFootballerTextField = new JTextField();
    JLabel currentDreamCarAnswer = new JLabel("Current answer for Dream car :");
    JLabel currentFavoriteFoodAnswer =  new JLabel("Current answer for favorite food :");
    JLabel currentFavoriteFootballerAnswer = new JLabel("Current answer for favorite footballer :");
    JLabel newDreamCarAnswer = new JLabel("Enter new answer for Dream car :");
    JLabel newFavoriteFoodAnswer = new JLabel("Enter new answer for favorite food :");
    JLabel newFavoriteFootballerAnswer = new JLabel("Enter new answer for favorite footballer :");

    ArrayList<String> holder = new ArrayList<String>();
    ArrayList<String> pqHolder = new ArrayList<String>();

    File file = new File("ownerSecurityInfo.txt");
    File ownerPqFile = new File("ownerPqAnswer.txt");

    ownerSecurityDetails()
    {
        try 
        {
            Scanner Reader = new Scanner(file);
            Scanner ownerPqFileReader = new Scanner(ownerPqFile);
            while (Reader.hasNextLine())
            {
                String data = Reader.nextLine();
                holder.add(data);
            }
            Reader.close();
            while (ownerPqFileReader.hasNextLine()) 
            {
                String data = ownerPqFileReader.nextLine();
                pqHolder.add(data);
            }
            ownerPqFileReader.close();
            
        } 
        catch (Exception e) 
        {
            System.out.println("an error ocurred in accessing the database, rebooting in process");
        }

        JTextField currentUsernamTextField = new JTextField(holder.get(0));
        JTextField currentPasswordtextfield = new JTextField(holder.get(1));
        JTextField currentDreamCarTextField = new JTextField(pqHolder.get(0));
        JTextField currentFavoriteFoodTextField = new JTextField(pqHolder.get(1));
        JTextField currentFavoriteFootballerTextField = new JTextField(pqHolder.get(2));

        ImageIcon settingsIcon = new ImageIcon("settingsIcon.png");

        passwordButton.setBounds(15,400,150,50);
        passwordButton.addActionListener(this);
        passwordButton.setFocusable(false);

        usernameButton.setBounds(15,200,150,50);
        usernameButton.addActionListener(this);
        usernameButton.setFocusable(false);

        CarPqButton.setBounds(300,190,200,25);
        CarPqButton.addActionListener(this);
        CarPqButton.setFocusable(false);

        FoodPqButton.setBounds(300,330,200,25);
        FoodPqButton.addActionListener(this);
        FoodPqButton.setFocusable(false);

        FootballerPqButton.setBounds(300,480,230,25);
        FootballerPqButton.addActionListener(this);
        FootballerPqButton.setFocusable(false);
        
        currentUsernamTextField.setBounds(15, 100, 150, 25);
        currentUsernameLabel.setBounds(15, 30,150,100);
        newUsernamTextField.setBounds(15,150,200,25);
        newUsernamLabel.setBounds(15,120,250,25);

        currentPasswordtextfield.setBounds(15,300,200,25);
        currentPasswordLabel.setBounds(15,230,150,100);
        newPasswordtTextField.setBounds(15,350,200,25);
        newPasswordLabel.setBounds(15,290,150,100);

        currentDreamCarAnswer.setBounds(300, 80, 200, 25);
        currentDreamCarTextField.setBounds(300,100,200,25);
        newDreamCarAnswer.setBounds(300, 120, 200, 25);
        newDreamCarTextField.setBounds(300, 150, 200, 25);
        
        currentFavoriteFoodAnswer.setBounds(300, 220, 200, 25);
        currentFavoriteFoodTextField.setBounds(300, 250, 200, 25);
        newFavoriteFoodAnswer.setBounds(300, 270, 250, 25);
        newFavoriteFoodTextField.setBounds(300, 300, 200, 25);

        currentFavoriteFootballerAnswer.setBounds(300, 370, 250, 25);
        currentFavoriteFootballerTextField.setBounds(300, 400, 200, 25);
        newFavoriteFootballerAnswer.setBounds(300, 420, 250, 25);
        newFavoriteFootballerTextField.setBounds(300, 450, 200, 25);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setSize(550,550);
        this.setVisible(true);
        this.setTitle("Security Details");
        this.add(passwordButton);
        this.add(usernameButton);
        this.add(currentUsernamTextField);
        this.add(currentUsernameLabel);
        this.add(newUsernamTextField);
        this.add(newUsernamLabel);
        this.add(currentPasswordtextfield);
        this.add(currentPasswordLabel);
        this.add(newPasswordtTextField);
        this.add(newPasswordLabel);
        this.add(currentDreamCarTextField);
        this.add(currentFavoriteFoodTextField);
        this.add(currentFavoriteFootballerTextField);
        this.add(newDreamCarTextField);
        this.add(newFavoriteFoodTextField);
        this.add(newFavoriteFootballerTextField);
        this.add(newDreamCarAnswer);
        this.add(newFavoriteFoodAnswer);
        this.add(newFavoriteFootballerAnswer);
        this.add(currentDreamCarAnswer);
        this.add(currentFavoriteFoodAnswer);
        this.add(currentFavoriteFootballerAnswer);
        this.add(CarPqButton);
        this.add(FoodPqButton);
        this.add(FootballerPqButton);
        this.setIconImage(settingsIcon.getImage());
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String usernameHolder = holder.get(0);
        String passwordHolder = holder.get(1);
        String carHolder = pqHolder.get(0);
        String foodHolder = pqHolder.get(1);
        String footballerHolder = pqHolder.get(2);

        if (e.getSource() == passwordButton) 
        {      
            try 
            {
                FileWriter writer = new FileWriter("ownerSecurityInfo.txt");
                writer.write(usernameHolder);
                writer.write("\n");
                writer.write(newPasswordtTextField.getText());
                writer.close();
                System.out.println("change was successful");
                
            } 
            catch (Exception a) 
            {
                System.out.println("error in accessing database, reboot in progress");
            }
        }

        if (e.getSource() == usernameButton)
        {
            try 
            {
                FileWriter writer = new FileWriter("ownerSecurityInfo.txt");
                writer.write(newUsernamTextField.getText());
                writer.write("\n");
                writer.write(passwordHolder);
                writer.close();
                System.out.println("change was succesful");

            } 
            catch (Exception a) 
            {
                System.out.println("error in accessing database, reboot in progress");
            }
        }
        if (e.getSource() == CarPqButton) 
        {
            try 
            {
                FileWriter writer = new FileWriter("ownerPqAnswer.txt");
                writer.write(newDreamCarTextField.getText());
                writer.write("\n");
                writer.write(foodHolder);
                writer.write("\n");
                writer.write(footballerHolder);
                writer.close();
                System.out.println("change was succesful");
            } 
            catch (Exception a) 
            {
                System.out.println("error in accessing database, reboot in progress");
            }
        }
        if (e.getSource() == FoodPqButton) 
        {            
            try 
            {
                FileWriter writer = new FileWriter("ownerPqAnswer.txt");
                writer.write(carHolder);
                writer.write("\n");
                writer.write(newFavoriteFoodTextField.getText());
                writer.write("\n");
                writer.write(footballerHolder);
                writer.close();
                System.out.println("change was succesful");                                           
            } 
            catch (Exception a) 
            {
                System.out.println("error in accessing database, reboot in progress");
            }
        }
        if (e.getSource() == FootballerPqButton) 
        {
           try 
           {
                FileWriter writer = new FileWriter("ownerPqAnswer.txt");
                writer.write(carHolder);
                writer.write("\n");  
                writer.write(foodHolder);
                writer.write("\n");     
                writer.write(newFavoriteFootballerTextField.getText());
                writer.close();
                System.out.println("change was succesful");                                                 
           } 
           catch (Exception a) 
           {
                System.out.println("error in accessing database, reboot in progress");
           }
        }
    }
    
}
