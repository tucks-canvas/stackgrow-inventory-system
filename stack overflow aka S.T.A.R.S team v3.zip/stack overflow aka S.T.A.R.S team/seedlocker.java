import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

public class seedlocker implements ActionListener{

    JFrame frame = new JFrame();
    JButton bit_loginButton = new JButton("Enter");
    JButton bit_resestButton = new JButton("Reset");
    JLabel bitlabel = new JLabel("bit combination ---->");
    JPasswordField passwordBitfield = new JPasswordField();
    String data = "";
    seedlocker()
    {
        try 
        {
            File seedlockerFile = new File("seedlockerpassword.txt");
            Scanner reader = new Scanner(seedlockerFile);

            while (reader.hasNextLine()) 
            {
                data = reader.nextLine();
            }
            System.out.println(data);
            reader.close();
        } 
        catch (Exception e) 
        {
            System.err.println("error in accessing the database rebooting...");
        }

        bitlabel.setBounds(50, 100, 75, 25);

        passwordBitfield.setBounds(125,100,200,25);

        bit_loginButton.setBounds(125,200,100,25);
        bit_loginButton.addActionListener(this);
        bit_loginButton.setFocusable(false);

        bit_resestButton.setBounds(225,200,100,25);
        bit_resestButton.addActionListener(this);
        bit_resestButton.setFocusable(false);

        frame.add(bitlabel);
        frame.add(passwordBitfield);
        frame.add(bit_loginButton);
        frame.add(bit_resestButton);
        frame.getContentPane().setBackground(new Color(70,130,180));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bit_loginButton)
        {
            String bitlockerpassword = String.valueOf(passwordBitfield.getPassword());
            if (bitlockerpassword.equals(data))
            {
                System.out.println("welcome");
                frame.dispose();
                new loginpage();
                
            }
            else
            {
                System.out.println("SUS");
            }
        }

        if (e.getSource() == bit_resestButton)
        {
            passwordBitfield.setText("");
        }
        
    }
    
}
