import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class employeeMainMenu extends JFrame implements ActionListener{

    JButton button = new JButton();;
    JButton settingsButton = new JButton();

    employeeMainMenu()
    {

        button.setBounds(200,100,100,50);
        button.addActionListener(e -> System.out.println("GOD is good"));
        button.setText("Hey wanna click this button");
        button.setFocusable(false);

        settingsButton.setBounds(200, 200,100,50);
        settingsButton.addActionListener(this);
        settingsButton.setText("security settings");
        settingsButton.setFocusable(false);

        ImageIcon icon = new ImageIcon("icon.png");

        this.setSize(420, 420);
        this.setLayout(null);
        this.setTitle("The Backlogs - employee");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setIconImage(icon.getImage());
        this.setVisible(true);
        this.add(button);
        this.add(settingsButton);
        this.getContentPane().setBackground(new Color(250, 95, 85));
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource() == settingsButton)
        {
            new employeeSecurityDetails();
        }
    }
    
}
