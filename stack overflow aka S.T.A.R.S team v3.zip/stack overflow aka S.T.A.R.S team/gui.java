
public class gui

{

    public static void main (String[] args)
    {

        new seedlocker();
        // new loginpage();
        // new encryption();
        // new mainmenu();
        //  new settings();
        // new employeeSecurityDetails();
        // new ownerSecurityDetails();



    }


}